import { AfterViewInit, ElementRef, Pipe, PipeTransform } from '@angular/core';



@Pipe({
  name: 'currencyExchange',


})
export class CurrencyExchangePipe implements PipeTransform,AfterViewInit {
  country:any;
  
transform(value:number, country:string): string {
  
  this.country = country;
  
  
    if(country.toLowerCase()=="india")
    {
      
      

      return "INR " + value;
      
    }
    if(country.toLowerCase()=="usa")
    {
      
      return "USD " + value;
    }
    if(country.toLowerCase()=="europe")
    {
      
      return "GBP " + value;
    }
    return "No currency"

  }
  
ngAfterViewInit():void{

  
}
}

  
   


