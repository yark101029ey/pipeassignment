import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EMployeeComponent implements OnInit {

  constructor() { }
 
    employeeJson=[
      {"EmpCode" : "e101", "EmpName": "saurabh", "Gender":"MALE", "Salary":55000, "DOB":"Sun May 24 1982 19:16:23","Country" :"India","MartialStatus":"Married"},
      {"EmpCode" : "e102", "EmpName": "priYANKA", "Gender":"female", "Salary":95000, "DOB":"Sun May 24 1984 19:16:23","Country" :"USA","MartialStatus":"UnMarried"},
      {"EmpCode" : "E103", "EmpName": "ROHIT", "Gender":"MALE", "Salary":75000, "DOB":"Sun May 24 1995 19:16:23","Country" :"Europe","MartialStatus":"UnMarried"},
      {"EmpCode" : "E104", "EmpName": "Shobit", "Gender":"MALE", "Salary":45000, "DOB":"Sun May 24 1994 19:16:23" ,"Country" :"India","MartialStatus":"Married"},
      {"EmpCode" : "e105", "EmpName": "AnkITA", "Gender":"Female", "Salary":75000 , "DOB":"Sun May 24 1993 19:16:23" ,"Country" :"India","MartialStatus":"Married"},
      {"EmpCode" : "e106", "EmpName": "AMEER", "Gender":"MALE", "Salary":85000 , "DOB":"Sun May 24 1990 19:16:23","Country" :"Europe","MartialStatus":"Married"},
      {"EmpCode" : "E107", "EmpName": "RAjIT", "Gender":"MALE", "Salary":95000 , "DOB":"Sun May 30 1983 19:16:23","Country" :"USA","MartialStatus":"UnMarried"},
      {"EmpCode" : "E108", "EmpName": "anamika", "Gender":"Female", "Salary":95000 , "DOB":"Sun May 24 1984 19:16:23","Country" :"USA","MartialStatus":"Married"},
      {"EmpCode" : "E109", "EmpName": "SWATI", "Gender":"Female", "Salary":95000 , "DOB":"Sun May 24 1990 19:16:23","Country" :"Europe","MartialStatus":"Married"},
      {"EmpCode" : "e110", "EmpName": "GAyathri", "Gender":"Female", "Salary":95000 , "DOB":"Sun May 24 1983 19:16:23","Country" :"India","MartialStatus":"Married"},
      {"EmpCode" : "E111", "EmpName": "Tushar", "Gender":"MALE", "Salary":95000 , "DOB":"Sun May 24 1983 19:16:23","Country" :"USA","MartialStatus":"Married"},
     ]
  
     
  ngOnInit(): void {
  }

}
