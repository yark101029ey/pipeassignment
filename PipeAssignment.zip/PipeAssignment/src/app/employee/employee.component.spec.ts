import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EMployeeComponent } from './employee.component';

describe('EMployeeComponent', () => {
  let component: EMployeeComponent;
  let fixture: ComponentFixture<EMployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EMployeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EMployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
