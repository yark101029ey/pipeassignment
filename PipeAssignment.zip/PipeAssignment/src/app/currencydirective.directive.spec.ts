import { CurrencydirectiveDirective } from './currencydirective.directive';

describe('CurrencydirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CurrencydirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
