import { CurrencyExcahngePipe } from './currency-excahnge.pipe';

describe('CurrencyExcahngePipe', () => {
  it('create an instance', () => {
    const pipe = new CurrencyExcahngePipe();
    expect(pipe).toBeTruthy();
  });
});
