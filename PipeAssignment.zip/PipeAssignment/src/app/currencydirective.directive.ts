import { Directive ,ElementRef} from '@angular/core';
import {EMployeeComponent} from './employee/employee.component'

@Directive({
  selector: '[appCurrencydirective]'
})
export class CurrencydirectiveDirective {

  value:any;
  constructor(private element: ElementRef, private objCurrency:EMployeeComponent) {

  }
  ngOnInit() {
    console.log(Object.values(this.objCurrency.employeeJson));
    
       for(var i = 0; i < this.objCurrency.employeeJson.length;i++) {
        this.value=this.objCurrency.employeeJson.length;
      //console.log(this.value)
        for(var z = 0; z < this.value.length; z++) 
        {
            console.log(this.objCurrency.employeeJson.length[i][z] + " ");
        }
       if (this.objCurrency.employeeJson[i].Country.toLowerCase() == 'india') {
           this.element.nativeElement.style.backgroundColor = 'red';
         }
       if (this.objCurrency.employeeJson[i].Country.toLowerCase() == 'usa') {
          this.element.nativeElement.style.backgroundColor = 'blue';
        }
      }
    }
  }

